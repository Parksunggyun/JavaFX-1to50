package main;
import layout.GameOverPanel;

import java.awt.Toolkit;
import java.net.URL;
import java.util.ResourceBundle;


import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.util.Duration;




public class FasterController implements Initializable{
	@FXML private Button clickBtn1;
	@FXML private Button clickBtn2;
	@FXML private Button clickBtn3;
	@FXML private Button clickBtn4;
	@FXML private Button clickBtn5;
	@FXML private Button clickBtn6;
	@FXML private Button clickBtn7;
	@FXML private Button clickBtn8;
	@FXML private Button clickBtn9;
	@FXML private Button clickBtn10;
	@FXML private Button clickBtn11;
	@FXML private Button clickBtn12;
	@FXML private Button clickBtn13;
	@FXML private Button clickBtn14;
	@FXML private Button clickBtn15;
	@FXML private Button clickBtn16;
	@FXML private Button clickBtn17;
	@FXML private Button clickBtn18;
	@FXML private Button clickBtn19;
	@FXML private Button clickBtn20;
	@FXML private Button clickBtn21;
	@FXML private Button clickBtn22;
	@FXML private Button clickBtn23;
	@FXML private Button clickBtn24;
	@FXML private Button clickBtn25; // JavaFX ��ư
    @FXML private Button newGame; // �� ���� ��ư
    @FXML private ToggleButton pauseButton;// Pause �� Start�� �� ��ư
    @FXML private AnchorPane gamePanel; // ���� ���̾ƿ�
    @FXML private GameOverPanel gameOverPanel; // ���� ���� ������ �ʾҽ��ϴ� 50�� Ŭ������ �� �ɸ� �ð��� ������ �˾�â.
    @FXML private Label timeCheck; // �ð��� ǥ���� �ִ� Label
    @FXML private Text currentNumber;
	int number[] = new int[50]; // �켱 1���� 25������ ���ڰ� ��ư�� ���� �迭�ǰ� �����Ƿ� int �迭�� ũ�⸦ 25�� �߽��ϴ�.
    private Boolean isStart = false; // �������� �Ǵ��� �ʵ�.
    int count = 1;
    private final BooleanProperty isPause = new SimpleBooleanProperty(); // �������� �Ǵ��� �ʵ�
    //private final BooleanProperty isGameOver = new SimpleBooleanProperty();
    
    private Timeline timeLine; 
    private DoubleProperty timeSeconds = new SimpleDoubleProperty();
    private Duration time = Duration.ZERO;
    public BtnEvent btnEvent = new BtnEvent();
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		timeCheck.textProperty().bind(timeSeconds.asString()); // �ð� Label�� timeSeconds ���ڸ� StringŸ������ ����
		gamePanel.setFocusTraversable(true);
        gamePanel.requestFocus();
		 pauseButton.selectedProperty().bindBidirectional(isPause); //Pause��ư�� Boolean Ÿ�� ����
		 pauseButton.selectedProperty().addListener(new ChangeListener<Boolean>() { // Pause �� Start �����ư��� ǥ��
	            @Override
	            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
	                if (newValue) {                                                  //���� ��                          // ���ο� ��
	                    timeLine.pause();
	                    pauseButton.setText("Start");
	                } else {
	                    timeLine.play();
	                    pauseButton.setText("Pause");
	                }
	            }
	        });	
		 timeLine = new Timeline(); // timeLine ��ü �ʱ�ȭ
	        timeLine.setCycleCount(Timeline.INDEFINITE);
	        timeLine.play();
	        
	        
	}

    public void startBtn(ActionEvent actionEvent){
    	timeLine.stop(); // �� ������ �� ������ Ÿ�Ӷ����� �ٽ� ���۵Ǿ�� �ϹǷ� stop��Ŵ.
    	time = Duration.ZERO; // time�� ���� �� ������ �� ������ 0�̵Ǿ�� ��.
    	timeCheck.textProperty().bind(timeSeconds.asString()); // timeCheck �� timeSeconds �� ����
    	count=1;
    	isStart=true; //startBtn�� Ŭ�������Ƿ� isStart �� true��
    	if(isStart == true){ 
    		setButtonNuber(); // �� ��ư�� ���� ���� ����.
          	 if (timeLine == null) {
        		  // ���� �� �� ����.
             } else {
                 timeLine = new Timeline(
                     new KeyFrame(Duration.millis(10), // 0.01�� ������ üũ
                     new EventHandler<ActionEvent>() {
                         @Override
                         public void handle(ActionEvent t) {
                             Duration duration = ((KeyFrame)t.getSource()).getTime();
                             time = time.add(duration);
                             timeSeconds.set(time.toSeconds());
                          }
                     })
                 );
                 timeLine.setCycleCount(Timeline.INDEFINITE);
                 timeLine.play();
             }
        	
        }
    	
    }
    
	public void setButtonNuber(){
		Button[] clickBtn = 
				{clickBtn1,clickBtn2,clickBtn3,clickBtn4,clickBtn5,clickBtn6,clickBtn7,clickBtn8,clickBtn9,
			    		clickBtn10,clickBtn11,clickBtn12,clickBtn13,clickBtn14,clickBtn15,clickBtn16,clickBtn17,clickBtn18,clickBtn19,
			    		clickBtn20,clickBtn21,clickBtn22,clickBtn23,clickBtn24,clickBtn25}; // 25���� ��ư�� Button �迭�� ����
    	for(int i=0;i<clickBtn.length;i++){
    		number[i] = (int)(Math.random()*25)+1;
    		for(int j=i-1;j>=0;j--){
    			if(number[i]==(number[j])){
    			i--;
    			break;
    			          }
    			
    			}
    		clickBtn[i].setText(String.valueOf(number[i]));
    		}   // �ߺ� �� ���� ���� 1~25 ���� ��ġ
    	
		
    	}

	public int numCount(){
		return count++;
	}
	public void actionBtn1(ActionEvent actionEvent){		
		int getText = Integer.parseInt(clickBtn1.getText());
		    if(getText == 50){
		    	timeLine.stop();
		    }else if(getText - count == 0 && getText >= 26){
				clickBtn1.setVisible(false);
				clickBtn1.isDisabled();
				System.out.println(getText);
				numCount();
			}else if(Integer.parseInt(clickBtn1.getText()) - count == 0){
				clickBtn1.setText(String.valueOf(getText+25));
				numCount();
			}else if(Integer.parseInt(clickBtn1.getText()) - count != 0){
				Thread thread = new Thread() {
					   @Override // ������ ���� �ʴ� ���� ������ �� ������
					   public void run() {  
					    Toolkit toolkit = Toolkit.getDefaultToolkit(); 
					    for(int i=0; i<1; i++) {  
					     toolkit.beep();
					     try { Thread.sleep(500); } catch(Exception e) {}
					    }
					   }
					  };				  
					  thread.start();
			}
			
	}
			

	public void actionBtn2(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn2.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn2.setVisible(false);
				clickBtn2.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn2.getText())- count == 0){
				
				clickBtn2.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn3(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn3.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn3.setVisible(false);
				clickBtn3.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn3.getText())- count == 0){
				
				clickBtn3.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn4(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn4.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn4.setVisible(false);
				clickBtn4.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn4.getText())- count == 0){
				
				clickBtn4.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn5(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn5.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn5.setVisible(false);
				clickBtn5.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn5.getText())- count == 0){
				
				clickBtn5.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn6(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn6.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn6.setVisible(false);
				clickBtn6.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn6.getText())- count == 0){
				
				clickBtn6.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn7(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn7.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn7.setVisible(false);
				clickBtn7.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn7.getText())- count == 0){
				
				clickBtn7.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn8(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn8.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn8.setVisible(false);
				clickBtn8.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn8.getText())- count == 0){
				
				clickBtn8.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn9(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn9.getText());
			if(getText - count == 0 && getText >= 26){
				clickBtn9.setVisible(false);
				clickBtn9.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn9.getText())- count == 0){
				
				clickBtn9.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn10(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn10.getText());
			if(getText - count == 0 && getText >= 26){
				clickBtn10.setVisible(false);
				clickBtn10.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn10.getText())- count == 0){
				
				clickBtn10.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn11(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn11.getText());
			if(getText - count == 0 && getText >= 26){
				clickBtn11.setVisible(false);
				clickBtn11.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn11.getText())- count == 0){
				
				clickBtn11.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn12(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn12.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn12.setVisible(false);
				clickBtn12.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn12.getText())- count == 0){
				
				clickBtn12.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn13(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn13.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn13.setVisible(false);
				clickBtn13.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn13.getText())- count == 0){
				
				clickBtn13.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn14(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn14.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn14.setVisible(false);
				clickBtn14.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn14.getText())- count == 0){
				
				clickBtn14.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn15(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn15.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn15.setVisible(false);
				clickBtn15.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn15.getText())- count == 0){
				
				clickBtn15.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn16(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn16.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn16.setVisible(false);
				clickBtn16.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn16.getText())- count == 0){
				
				clickBtn16.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn17(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn17.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn17.setVisible(false);
				clickBtn17.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn17.getText())- count == 0){
				
				clickBtn17.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn18(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn18.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn18.setVisible(false);
				clickBtn18.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn18.getText())- count == 0){
				
				clickBtn18.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn19(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn19.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn19.setVisible(false);
				clickBtn19.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn19.getText())- count == 0){
				
				clickBtn19.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn20(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn20.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn20.setVisible(false);
				clickBtn20.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn20.getText())- count == 0){
				
				clickBtn20.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn21(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn21.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn21.setVisible(false);
				clickBtn21.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn21.getText())- count == 0){
				
				clickBtn21.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn22(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn22.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn22.setVisible(false);
				clickBtn22.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn22.getText())- count == 0){
				
				clickBtn22.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn23(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn23.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn23.setVisible(false);
				clickBtn23.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn23.getText())- count == 0){
				
				clickBtn23.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	public void actionBtn24(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn24.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn24.setVisible(false);
				clickBtn24.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn24.getText())- count == 0){
				
				clickBtn24.setText(String.valueOf(getText+25));
				count++;
			}
		
	}
	public void actionBtn25(ActionEvent actionEvent){
		int getText = Integer.parseInt(clickBtn25.getText());
	    if(getText == 50){
	    	timeLine.stop();
	    }else if(getText - count == 0 && getText >= 26){
				clickBtn25.setVisible(false);
				clickBtn25.isDisabled();
				numCount();
			}else if(Integer.parseInt(clickBtn25.getText())- count == 0){
				
				clickBtn25.setText(String.valueOf(getText+25));
				numCount();
			}
		
	}
	/*
	public void gameOver() {
        timeLine.stop();
        gameOverPanel.setVisible(true);
        isGameOver.setValue(Boolean.TRUE);

    }
    */
	/*���� �����ϱ� ����� �ʿ��Ѱ�.
	 public void newGame(ActionEvent actionEvent) {
		timeLine.stop();
        gameOverPanel.setVisible(false);
        gamePanel.requestFocus();
        timeLine.play();
        isPause.setValue(Boolean.FALSE);
        isGameOver.setValue(Boolean.FALSE);
    }
    */
	public void pauseGame(ActionEvent actionEvent) { // �ð� ���߰� �̾ ��� �ݺ�
		if(pauseButton.getText().equals("Start")){
       timeLine.stop();
		}
		else if(pauseButton.getText().equals("Pause")){
			timeLine.play();
		}
    }

}
