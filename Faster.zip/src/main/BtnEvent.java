package main;

import javafx.scene.control.Button;

public class BtnEvent {
    
	public void clickEvent(Button[] button){
		for(int i=0;i<25;i++){
			int num = (int)(Math.random()*25) +1;
			if(button[i].getText().equals(num)){
				button[i].setText(num+"25");
		}
		
		}
	}
}
