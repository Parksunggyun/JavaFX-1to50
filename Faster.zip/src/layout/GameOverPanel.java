package layout;

import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;

public class GameOverPanel extends BorderPane {
	public GameOverPanel() {
		final Label gameOverPanel = new Label("TIME OUT!");
		gameOverPanel.getStyleClass().add("gameOverStyle");
		setCenter(gameOverPanel);
	}

}
